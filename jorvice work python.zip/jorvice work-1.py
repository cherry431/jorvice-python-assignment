def rotation (s1, s2):
    n = len(s2)
    if n != len(s1):
        return -1  # invalid input

    # concatenate s1 with itself to all possible rotations
    s2 = s2 + s2

    for i in range(n):
        if s2[i:i+n] == s1:
            return i  # found a rotation that matches s2

    return -1  # s2 cannot be obtained from s1 by rotating

# Example usage:
s1 = input()
s2 = input()
print(rotation (s1, s2))  # prints 3